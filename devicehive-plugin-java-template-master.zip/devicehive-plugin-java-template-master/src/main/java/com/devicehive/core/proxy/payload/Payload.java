package com.devicehive.core.proxy.payload;

public interface Payload {
}
