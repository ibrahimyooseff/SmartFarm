package com.devicehive.core.proxy;

public interface DhMessageHandler {
    void handleMessage(String message);
}
